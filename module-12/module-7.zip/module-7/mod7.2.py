# Keanu Foltz Module 7.2 CSD-325 12/1
#

def format_city_country(city, country):
    